export const OPEN_NEW = 'myportfolio/OPEN_NEW';
export const SAVE_MARKER = 'myportfolio/SAVE_MARKER';
export const UPDATE_MARKER = 'myportfolio/UPDATE_MARKER';
export const DELETE_MARKER = 'myportfolio/DELETE_MARKER';

export const openNew = location => ({
  type: OPEN_NEW,
  location
});
export const saveMarker = (position,text,selectedIcon) => ({
  type: SAVE_MARKER,
  payload:{position,text,selectedIcon}
});
export const updateMarker = (text,selectedIcon,index) => ({
  type: UPDATE_MARKER,
  payload:{text,selectedIcon,index}
});
export const deleteMarker = index => ({
  type: DELETE_MARKER,
  index
});