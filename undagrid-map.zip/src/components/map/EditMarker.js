import React, { Component, createRef } from 'react';
import { connect } from 'react-redux';
import { Popup, Marker } from 'react-leaflet';
import { icon } from 'leaflet';
import iconSelector from './iconSelector';

const mapStateToProps = (state,ownProps) => ({...ownProps.passed});

class EditMarker extends Component {
  constructor (props) {
    super(props);
    this.state = {text:props.text,selectedIcon:this.props.selectedIcon};
  }
  changeText (e) {
    this.setState({...this.state,text:e.target.value});
  }
  render() {
    return (
        <Marker position={this.props.position} icon={icon(this.props.icons[this.props.selectedIcon])}>
          <Popup>
            <h1>{this.props.text}</h1>
            <div>
              <input type="text" onChange={(e)=>this.changeText(e)} value={this.state.text} />
            </div>
            { iconSelector(this.props,this.state,this.setState.bind(this)) }
            <div>
              <input 
                type="button" 
                value="Save" 
                onClick={()=>this.props.updateMarker(
                  this.state.text,
                  this.state.selectedIcon,
                  this.props.index
                )} />
              <input 
                type="button" 
                value="Delete" 
                onClick={()=>this.props.deleteMarker(this.props.index)} />
            </div>
          </Popup>
          </Marker>
    );
  }
};

export default connect(mapStateToProps)(EditMarker);