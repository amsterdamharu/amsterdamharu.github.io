import React, { Component, createRef } from 'react';
import { connect } from 'react-redux';
import { Map as LeafletMap, TileLayer } from 'react-leaflet';

import NewPopup from './NewPopup';
import EditMarker from './EditMarker';
import { openNew, saveMarker, updateMarker,deleteMarker } from './actions';

const mapStateToProps = (state) => state.map;

const mapDispatchToProps = {
  openNew,
  saveMarker,
  updateMarker,
  deleteMarker
};
const passProps = (marker,index,props) => (
  {...marker,index,updateMarker:props.updateMarker,deleteMarker:props.deleteMarker,icons:props.icons}
);
class Map extends Component {
  mapRef = createRef()

  handleClick (e) {
    const location = this.mapRef.current.leafletElement.mouseEventToLatLng(e.originalEvent);
    this.props.openNew(location);
  }
  constructor() {
    super()
    this.state = {}
  }

  render() {
    const props = this.props;
    return (
      <LeafletMap 
        center={props.center}
        zoom={props.zoom}
        style={{width:"100%",height:"100%"}}
        onClick={(e)=>this.handleClick(e)}
        ref={this.mapRef}
      >
        <TileLayer
          attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          url='http://{s}.tile.osm.org/{z}/{x}/{y}.png'
        />
        {
          (props.showNewPopup)
            ? <NewPopup passed={this.props}/>
            : ""
        }
        {
          props.markers.map(
            (marker,index)=>(
              <EditMarker passed={passProps(marker,index,this.props)} key={index}/>
            )
          )
        }
      </LeafletMap>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Map);