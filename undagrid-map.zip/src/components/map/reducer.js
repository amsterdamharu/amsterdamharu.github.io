import { 
  OPEN_NEW, SAVE_MARKER, UPDATE_MARKER, DELETE_MARKER
} from "./actions";

//@todo: should be injected but need to change tests as well
var storage
if(process.env.NODE_ENV==="test"){
  storage={
    set:x=>undefined,
    get:()=>[]
  }
}else{
  storage = {
    set:markers=>localStorage.setItem("markers",JSON.stringify(markers)),
    get:()=>JSON.parse(localStorage.getItem("markers") || "[]")
  }
}

const initialState = {
  center:{lat: 52.369730195560706, lng: 4.901275634765625},
  zoom: 18,
  showNewPopup:false,
  newName:"",
  newCoords:{lat:0,lng:0},
  markers:storage.get(),
  icons:[
    {
      iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
      iconAnchor: [12, 41],
      popupAnchor: [0, -44]
    },
    {
      iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
      iconAnchor: [12, 41],
      popupAnchor: [0, -44]
    }
  ]
};

export default (state = initialState, action) => {
  var markers;
  switch (action.type) {
    case OPEN_NEW:
      return {
        ...state,
        showNewPopup:true,
        newCoords:action.location
      };
    case SAVE_MARKER:
      markers = state.markers.concat({...action.payload,selectedIcon:action.payload.selectedIcon});
      storage.set(markers)    
      return {
        ...state,
        showNewPopup:false,
        markers
      };
    case UPDATE_MARKER:
      markers = state.markers.map(
        (marker,index)=>
          (index===action.payload.index)
            ? {...marker,text:action.payload.text,selectedIcon:action.payload.selectedIcon}
            : marker
      );
      storage.set(markers);
      return {
        ...state,
        showNewPopup:false,
        markers
      };
    case DELETE_MARKER:
      markers=state.markers.filter((ignore,index)=>(index!==action.index));
      storage.set(markers);
      return {
        ...state,
        showNewPopup:false,
        markers
      };
    default:
      return state;
  }

}