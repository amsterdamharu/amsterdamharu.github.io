import { openNew,saveMarker,updateMarker,deleteMarker } from "./actions";
import reducer from './reducer';
describe(
  "map reducer",
  ()=>{
    const state = reducer(undefined,{type:""});
    const position = {};
    const savedMarker = reducer(undefined,saveMarker(position,"hi",1));
    const withMarkers = [["1",1],["2",2],["3",3]].reduce(
      (state,[text,selectedIcon])=>
        reducer(state,saveMarker(position,text,selectedIcon)),
      state
    );
    const removed2 = reducer(withMarkers,deleteMarker(1));
    const removed1 = reducer(withMarkers,deleteMarker(0));
    it('open new should set showNewPopup to true', () => {
      expect(reducer(state,openNew({})).showNewPopup).toBe(true);
    });
    it('open new should set newCoords to position', () => {
      expect(reducer(state,openNew(position)).newCoords).toBe(position);
    });
    it('save marker should have saved a marker', () => {
      expect(reducer(state,saveMarker(position,"hi",1)).markers[0].position).toBe(position);
      expect(reducer(state,saveMarker(position,"hi",1)).markers[0].text).toBe("hi");
      expect(reducer(state,saveMarker(position,"hi",1)).markers[0].selectedIcon).toBe(1);
    });
    it('update marker should have updaed the correct marker', () => {
      expect(reducer(savedMarker,updateMarker("change",0,0)).markers[0].position).toBe(position);
      expect(reducer(savedMarker,updateMarker("change",0,0)).markers[0].text).toBe("change");
      expect(reducer(savedMarker,updateMarker("change",0,0)).markers[0].selectedIcon).toBe(0);
    });
    it('delete marker should delete the right marker', () => {
      expect(removed2.markers.length).toBe(2);
      expect(removed2.markers[1].text).toBe("3");
      expect(removed1.markers.length).toBe(2);
      expect(removed1.markers[0].text).toBe("2");
    });

  }
);
