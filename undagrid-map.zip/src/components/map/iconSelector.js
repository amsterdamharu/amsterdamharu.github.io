import React from 'react';
export default (props,state,setState) => (
  <div>
    {
      props.icons.map(
        (icon,index)=>(
          <div key={index}>
            <img alt="icon" src={icon.iconUrl} key={index}/>
            <input 
              type="radio"
              checked={state.selectedIcon===index} 
              onChange={linterShutUp=>linterShutUp}
              onClick={e=>setState({...state,selectedIcon:index})}
            />
          </div>
        )
      )
    }
  </div>
)