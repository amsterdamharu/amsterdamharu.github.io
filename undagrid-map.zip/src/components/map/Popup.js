import { createRef } from 'react';
import { Popup as LeafletPopup } from 'react-leaflet';

export default class Popup extends LeafletPopup {
  popupRef = createRef()

  constructor() {
    super()
  }

  render(props) {
    return super.render(props);
  }
}
