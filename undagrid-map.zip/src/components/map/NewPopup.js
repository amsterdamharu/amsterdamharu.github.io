import React, { Component, createRef } from 'react';
import { connect } from 'react-redux';
import { Popup } from 'react-leaflet';

import iconSelector from './iconSelector';

const mapStateToProps = (state,ownProps) => ({
  position:ownProps.passed.newCoords,
  saveMarker:ownProps.passed.saveMarker,
  icons:ownProps.passed.icons
});

class NewPopup extends Component {
  popRef = createRef();
  componentDidUpdate(prevProps) {
    if(//@todo: bug if you don't move your mouse and click several times
      prevProps.position.lat!==this.props.position.lat ||
      prevProps.position.lng!==this.props.position.lng
    ){
      this.popRef.current.leafletElement.openOn(this.popRef.current.props.leaflet.map);
    }
  }
  constructor (props) {
    super(props);
    this.state = {text:"",selectedIcon:0};
  };
  changeText (e) {
    this.setState({...this.state,text:e.target.value});
  }
  render() {
    return (
      <div>
        <Popup position={this.props.position} ref={this.popRef}>
          <h1>New Marker</h1>
          <div>
            <input type="text" onChange={(e)=>this.changeText(e)} value={this.state.text} />
          </div>
          { iconSelector(this.props,this.state,this.setState.bind(this)) }
          <div>
          <input 
            type="button" 
            value="Save" 
            onClick={()=>this.props.saveMarker(this.props.position,this.state.text,this.state.selectedIcon)} 
          />
          </div>
        </Popup>
      </div>
    );
  }
};

export default connect(mapStateToProps)(NewPopup);