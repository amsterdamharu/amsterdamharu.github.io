import React from 'react';
import { render } from 'react-dom';
import { compose, createStore } from 'redux'
import { Provider } from 'react-redux'
import rootReducer from './reducers'

import './index.css';
import Map from './components/map/Map';
import registerServiceWorker from './registerServiceWorker';

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  rootReducer,
  composeEnhancers()
);


render(<Provider store={store}><Map /></Provider>, document.getElementById('root'));
registerServiceWorker();
